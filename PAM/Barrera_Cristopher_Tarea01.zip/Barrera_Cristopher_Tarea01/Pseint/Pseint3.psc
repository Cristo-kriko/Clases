Algoritmo Resoluci�nDeUnaImagen


	Definir ancho Como Entero;
	Definir alto Como Entero;
	definir pixeles como entero;
	Escribir "Escriba el ancho";
	Leer ancho;
	Escribir "Escriba el alto";
	Leer alto;

	pixeles = ancho * alto

	Escribir "P�xeles: ", pixeles

FinAlgoritmo
